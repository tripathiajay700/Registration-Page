function register(){
    let fname=document.forms["regForm"]["fname"].value;
    let arr1=[];
    if(/^$/.test(fname)){
        arr1.push("first name can't left blank");
    }else if(!/^[A-Za-z0-9$_]{8,16}$/.test(fname)){
        arr1.push("must follow rules and regulations");
    }
    document.getElementById("fname_errors").innerHTML=arr1.join(",");


    let lname=document.forms["regForm"]["lname"].value;
    let arr2=[];
    if(/^$/.test(lname)){
        arr2.push("Last name can't left blank");
    }else if(!/^[A-Za-z0-9$_]{8,16}$/.test(lname)){
        arr2.push("must follow rules and regulations");
    }
    document.getElementById("lname_errors").innerHTML=arr2.join(",");

    let psw=document.forms["regForm"]["psw"].value;
    let arr3=[];
    if(/^$/.test(psw)){
        arr3.push("password can't left blank");
    }else if(!/^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[@#$%&^]).{8,16}$/.test(psw)){
        arr3.push("must follow rules and regulations");
    }
    document.getElementById("psw_errors").innerHTML=arr3.join(",");

    let cpsw=document.forms["regForm"]["cpsw"].value;
    let arr4=[];
    if(/^$/.test(cpsw)){
        arr4.push("confirm password can't left blank");
    }else if(psw!=cpsw){
        arr4.push("password and confirm must match");
    }
    document.getElementById("cpsw_errors").innerHTML=arr4.join(",");



    let uemail=document.forms["regForm"]["uemail"].value;
    let arr5=[];
    if(/^$/.test(uemail)){
        arr5.push("email can't left blank");
    }else if(!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(uemail)){
        arr5.push("follow validation rules and regulation");
    }
    document.getElementById("uemail_errors").innerHTML=arr5.join(",");


    let phone=document.forms["regForm"]["phone"].value;
    let arr6=[];
    if(/^$/.test(phone)){
        arr6.push("phone can't left blank");
    }else if(!/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/.test(phone)){
        arr6.push("follow validation rules and regulation");
    }
    document.getElementById("phone_errors").innerHTML=arr6.join(",");


    let address=document.forms["regForm"]["address"].value;
    let arr7=[];
    if(/^$/.test(address)){
        arr7.push("address can't left blank");
    }
    document.getElementById("address_errors").innerHTML=arr7.join(",");


    let country=document.forms["regForm"]["country"].value;
    let arr8=[];
    if(/^$/.test(country)){
        arr8.push("country can't left blank");
    }
    document.getElementById("country_errors").innerHTML=arr8.join(",");


    document.getElementById("c").checked || document.getElementById("c++").checked || document.getElementById("java").checked || document.getElementById("dotnet").checked ? document.getElementById("skills_errors").innerHTML="" : document.getElementById("skills_errors").innerHTML="Select At Least One Language"; 



    document.getElementById("male").checked || document.getElementById("female").checked ? document.getElementById("gender_errors").innerHTML="": document.getElementById("gender_errors").innerHTML="Select Gender";


















 
    return false;
}